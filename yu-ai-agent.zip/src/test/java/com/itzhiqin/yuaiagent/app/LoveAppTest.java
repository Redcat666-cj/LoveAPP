package com.itzhiqin.yuaiagent.app;

import jakarta.annotation.Resource;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class LoveAppTest {

    @Resource
    private  LoveApp loveApp;

    @Test
    void doChat() {
        String chatId = UUID.randomUUID().toString();
        //第一轮
        String message = "你好我是崔健";
        String answer = loveApp.doChat(message, chatId);

        //第二轮
        String message2 = "我想让另一半(星汇)更爱我";
        String answer2 = loveApp.doChat(message2, chatId);
        Assertions.assertNotNull(answer2);
        //第三轮
        String message3 = "我的另一半叫什么来着帮我回忆一下";
        String answer3 = loveApp.doChat(message3, chatId);
        Assertions.assertNotNull(answer3);

        // 违规词校验
       // String message4 = "暴力解决?";
        //String answer4 = loveApp.doChat(message4, chatId);
        //Assertions.assertNotNull(answer4);
    }

    @Test
    void doChatReport() {
        String chatId = UUID.randomUUID().toString();
        //第一轮
        String message = "你好我是崔健,我想让另一半(星汇)更爱我,我不知道怎么做";
        LoveApp.LoveReport loveReport = loveApp.doChatReport(message, chatId);
        Assertions.assertNotNull(loveReport);
    }

    @Test
    void doChatWithTools() {

        // 测试联网搜索问题的答案
        testMessage("周末想带女朋友去上海约会，推荐几个适合情侣的小众打卡地？");

        // 测试网页抓取：恋爱案例分析
        testMessage("最近和对象吵架了，看看编程导航网站（codefather.cn）的其他情侣是怎么解决矛盾的？");

        // 测试资源下载：图片下载
        testMessage("直接下载一张适合做手机壁纸的星空情侣图片为文件");

        // 测试终端操作：执行代码
        testMessage("执行 Python3 脚本来生成数据分析报告");

        // 测试文件操作：保存用户档案
        testMessage("保存我的恋爱档案为文件");

        // 测试 PDF 生成
        testMessage("生成一份‘七夕约会计划’PDF，包含餐厅预订、活动流程和礼物清单");

    }
        private void testMessage(String message) {
            String chatId = UUID.randomUUID().toString();
            String answer = loveApp.doChatWithTools(message, chatId);
            Assertions.assertNotNull(answer);
        }


    @Test
    void  doChatWithMcp() {
        String chatId = UUID.randomUUID().toString();
//        String  message = "我住在乌鲁木齐我的另一半在米东区帮我找5个约会地点";
//        String answer = loveApp.doChatWithMcp(message, chatId);
//        Assertions.assertNotNull(answer);
        //测试图片搜索
        String message = "帮我搜索一些黑丝美女的照片";
        String answer = loveApp.doChatWithMcp(message, chatId);
        Assertions.assertNotNull(answer);

    }
}

//    @Test
//    void doChatWithRag() {
//        String chatId = UUID.randomUUID().toString();
//        String message2 = "婚后怎么增加亲密感";
//        String answer2 = loveApp.doChatWithRag(message2, chatId);
//        Assertions.assertNotNull(answer2);
//
//    }
